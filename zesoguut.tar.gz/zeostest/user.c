#include <libc.h>

char buff[24];
int __attribute__ ((__section__(".text.main")))
 
main(void) {

	for (int i = 0; i < 3; ++i) {
		int pid = fork()
		if (pid == 0) {
			// codgio hijo
		}
		else if (pid > 0) {
			fork()
		}
	}

	

	while(1) { }
}
